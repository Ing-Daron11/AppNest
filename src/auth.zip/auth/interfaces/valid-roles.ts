export enum ValidRoles {
  admin = 'admin',
  user = 'user',
  superuser = 'superuser',
}
